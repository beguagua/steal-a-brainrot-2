# 🚀 Instalação Rápida - Steal A Brainrot 2

## ⚡ Início Rápido (3 passos)

### 1. Extrair o ZIP
```bash
unzip steal-a-brainrot-2-game.zip
cd steal-a-brainrot-2/
```

### 2. Instalar Dependências
```bash
npm install
```

### 3. Iniciar o Jogo
```bash
npm start
```

**Pronto!** Acesse: http://localhost:3000

---

## 🎮 Controles Básicos

- **WASD**: Mover
- **Espaço**: Pular  
- **E**: Interagir
- **B**: Construir
- **T**: Roubar

## 🏆 Objetivo

1. Compre Brainrots no mercado central
2. Construa sua base para protegê-los
3. Roube Brainrots de outros jogadores
4. Suba no ranking global!

---

## ⚠️ Requisitos

- Node.js 16+ 
- Navegador moderno (Chrome/Firefox)
- Porta 3000 disponível

## 🆘 Problemas?

- **Áudio não funciona**: Clique na tela
- **Lag**: Feche outras abas
- **Não conecta**: Verifique se a porta 3000 está livre

---

**Divirta-se! 🧠💰**
