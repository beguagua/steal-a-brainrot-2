# Steal A Brainrot 2 🧠💰

Um jogo 3D online multiplayer baseado na cultura de memes "Brainrot" italiana, onde os jogadores constroem bases, coletam personagens Brainrot e roubam uns dos outros em um mundo 3D colorido e caótico.

## 🎮 Sobre o Jogo

**Steal A Brainrot 2** é a sequência 3D do popular jogo "Steal Brainrot Online". Os jogadores entram em um mundo multiplayer onde podem:

- **Coletar Brainrots**: Compre ou roube personagens únicos como Tralalero Tralala, Cappuccino Assassino e Bombardino Crocodilo
- **Construir Bases**: Crie e personalize sua base 3D com paredes, armadilhas e decorações
- **Roubar de Outros**: Invada bases de outros jogadores para roubar seus Brainrots valiosos
- **Competir no Ranking**: Suba no leaderboard global baseado em dinheiro e coleção de Brainrots
- **Interagir Socialmente**: Chat em tempo real e eventos multiplayer

## 🚀 Características Técnicas

- **Engine 3D**: Three.js para renderização WebGL
- **Multiplayer**: Socket.IO para comunicação em tempo real
- **Áudio Procedural**: Sistema de som gerado dinamicamente
- **Texturas Customizadas**: Assets visuais únicos para cada Brainrot
- **Arquitetura Full-Stack**: Frontend JavaScript + Backend Node.js

## 📋 Requisitos

- **Node.js**: versão 16.0.0 ou superior
- **NPM**: versão 8.0.0 ou superior
- **Navegador**: Chrome, Firefox, Safari ou Edge (com suporte a WebGL)

## 🛠️ Instalação e Execução

### 1. Instalar Dependências
```bash
npm install
```

### 2. Iniciar o Servidor
```bash
npm start
```
ou para desenvolvimento:
```bash
npm run dev
```

### 3. Acessar o Jogo
Abra seu navegador e acesse:
```
http://localhost:3000
```

## 🎯 Como Jogar

### Controles Básicos
- **WASD** ou **Setas**: Mover o jogador
- **Espaço**: Pular
- **E**: Interagir com objetos
- **G**: Voltar para casa (escape de emergência)
- **F**: Interagir com objeto mais próximo
- **R**: Ativar escudo da base
- **B**: Alternar modo de construção
- **T**: Alternar modo de roubo

### Botões da Interface
- **🏗️ Construir**: Ativar modo de construção
- **🛒 Loja**: Abrir loja de Brainrots
- **💰 Roubar**: Ativar modo de roubo
- **💬 Chat**: Abrir/fechar chat
- **🏆 Ranking**: Ver leaderboard

### Mecânicas do Jogo

#### Coleta de Brainrots
- Compre Brainrots no mercado central usando dinheiro
- Cada Brainrot gera renda passiva quando colocado na sua base
- Tipos disponíveis: Tralalero, Cappuccino, Bombardino, Tung Sahur, Memes Raros

#### Sistema de Roubo
- Entre no modo roubo e aproxime-se de bases de outros jogadores
- Bases destrancadas podem ser invadidas
- Carregue o Brainrot roubado de volta à sua base para completar o roubo
- Cuidado: o dono pode perseguir você e recuperar o item!

#### Construção de Base
- Use o modo construção para adicionar paredes, armadilhas e decorações
- Cada estrutura tem um custo em dinheiro
- Defesas ajudam a proteger seus Brainrots de ladrões

#### Sistema de Escudo
- Ative escudos temporários (60 segundos) por $100
- Bases com escudo não podem ser invadidas
- Use estrategicamente quando tiver muitos Brainrots valiosos

## 🏗️ Estrutura do Projeto

```
steal-a-brainrot-2/
├── server.js              # Servidor principal Node.js
├── package.json           # Configuração do projeto
├── README.md             # Este arquivo
├── public/               # Arquivos do cliente
│   ├── index.html        # Página principal
│   ├── game.js          # Lógica principal do jogo
│   ├── gameplay.js      # Sistema de mecânicas
│   ├── textureManager.js # Gerenciamento de texturas
│   ├── audioManager.js   # Sistema de áudio
│   ├── leaderboard.js    # Sistema de ranking
│   └── assets/           # Assets do jogo
│       └── textures/     # Texturas e imagens
└── client/               # Arquivos de desenvolvimento
    ├── js/
    ├── css/
    └── assets/
```

## 🎨 Assets e Texturas

O jogo inclui texturas customizadas para:
- **Personagens Brainrot**: Cada tipo tem sua textura única
- **Ambiente**: Grama, plataformas e decorações
- **Interface**: Ícones para dinheiro, Brainrots e jogadores
- **Estruturas**: Materiais para construção de bases

## 🔊 Sistema de Áudio

Todos os sons são gerados proceduralmente usando Web Audio API:
- **Efeitos Sonoros**: Coleta de moedas, roubo, construção, erro
- **Música Ambiente**: Loop de 30 segundos com camadas harmônicas
- **Áudio Espacial**: Sons posicionais baseados na localização
- **Notificações**: Chat e eventos do jogo

## 🌐 Funcionalidades Multiplayer

- **Sincronização em Tempo Real**: Movimentos e ações de todos os jogadores
- **Chat Global**: Comunicação entre jogadores
- **Eventos Compartilhados**: Notificações de roubos e conquistas
- **Leaderboard Dinâmico**: Ranking atualizado automaticamente
- **Persistência de Sessão**: Estado do jogo mantido durante a conexão

## 🚀 Deployment

### Desenvolvimento Local
```bash
npm run dev
```

### Produção
```bash
npm start
```

### Variáveis de Ambiente
Crie um arquivo `.env` (opcional):
```
PORT=3000
NODE_ENV=production
```

## 🐛 Solução de Problemas

### Áudio não Funciona
- Clique em qualquer lugar da tela para ativar o contexto de áudio
- Verifique se o navegador permite reprodução automática de áudio

### Lag ou Performance Baixa
- Feche outras abas do navegador
- Reduza a qualidade gráfica nas configurações
- Verifique se o WebGL está habilitado

### Problemas de Conexão
- Verifique se a porta 3000 está disponível
- Desative firewalls que possam bloquear WebSockets
- Tente acessar via localhost em vez de 127.0.0.1

## 📝 Changelog

### Versão 2.0.0
- **Novo**: Renderização 3D completa com Three.js
- **Novo**: Sistema de áudio procedural
- **Novo**: Texturas customizadas para todos os Brainrots
- **Novo**: Sistema de leaderboard em tempo real
- **Novo**: Mecânicas de construção de base expandidas
- **Melhorado**: Interface de usuário mais intuitiva
- **Melhorado**: Performance e otimizações gráficas

## 🤝 Contribuição

Este projeto foi criado pela Manus AI como demonstração de desenvolvimento de jogos web full-stack. 

## 📄 Licença

MIT License - veja o arquivo LICENSE para detalhes.

## 🎉 Créditos

- **Desenvolvimento**: Manus AI
- **Inspiração**: Cultura de memes Brainrot italiana
- **Tecnologias**: Three.js, Node.js, Socket.IO
- **Arte**: Texturas geradas por IA

---

**Divirta-se roubando Brainrots! 🧠💰**
