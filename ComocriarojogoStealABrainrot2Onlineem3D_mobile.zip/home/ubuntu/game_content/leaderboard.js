export class LeaderboardManager {
    constructor(game) {
        this.game = game;
        this.leaderboardData = [];
        this.isVisible = false;
        this.updateInterval = null;
        
        this.setupLeaderboard();
    }

    setupLeaderboard() {
        // Add leaderboard button to UI
        this.addLeaderboardButton();
        
        // Create leaderboard panel
        this.createLeaderboardPanel();
        
        // Setup socket listeners
        this.setupSocketListeners();
        
        // Auto-update leaderboard every 30 seconds
        this.updateInterval = setInterval(() => {
            this.requestLeaderboard();
        }, 30000);
    }

    addLeaderboardButton() {
        const bottomPanel = document.getElementById('bottomPanel');
        if (bottomPanel) {
            const leaderboardBtn = document.createElement('button');
            leaderboardBtn.className = 'action-btn';
            leaderboardBtn.id = 'leaderboardBtn';
            leaderboardBtn.innerHTML = '🏆 Ranking';
            leaderboardBtn.addEventListener('click', () => this.toggleLeaderboard());
            bottomPanel.appendChild(leaderboardBtn);
        }
    }

    createLeaderboardPanel() {
        const leaderboardPanel = document.createElement('div');
        leaderboardPanel.id = 'leaderboardPanel';
        leaderboardPanel.className = 'ui-panel';
        leaderboardPanel.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            max-height: 600px;
            overflow-y: auto;
            z-index: 300;
            display: none;
        `;

        const title = document.createElement('h2');
        title.textContent = '🏆 Ranking dos Jogadores';
        title.style.textAlign = 'center';
        title.style.marginBottom = '20px';
        title.style.color = '#ffd700';
        leaderboardPanel.appendChild(title);

        const leaderboardList = document.createElement('div');
        leaderboardList.id = 'leaderboardList';
        leaderboardPanel.appendChild(leaderboardList);

        const closeButton = document.createElement('button');
        closeButton.className = 'action-btn';
        closeButton.textContent = '❌ Fechar';
        closeButton.style.width = '100%';
        closeButton.style.marginTop = '20px';
        closeButton.addEventListener('click', () => this.hideLeaderboard());
        leaderboardPanel.appendChild(closeButton);

        document.getElementById('ui').appendChild(leaderboardPanel);
    }

    setupSocketListeners() {
        this.game.socket.on('leaderboard', (data) => {
            this.leaderboardData = data;
            this.updateLeaderboardDisplay();
        });

        this.game.socket.on('gameEvent', (event) => {
            if (event.type === 'stealCompleted') {
                this.showGameEvent(`${event.thiefName} roubou um ${event.brainrotType}!`);
            }
        });
    }

    toggleLeaderboard() {
        if (this.isVisible) {
            this.hideLeaderboard();
        } else {
            this.showLeaderboard();
        }
    }

    showLeaderboard() {
        this.requestLeaderboard();
        document.getElementById('leaderboardPanel').style.display = 'block';
        this.isVisible = true;
        
        const btn = document.getElementById('leaderboardBtn');
        btn.style.background = 'linear-gradient(135deg, #ffd700 0%, #ffed4e 100%)';
        btn.style.color = '#000';
    }

    hideLeaderboard() {
        document.getElementById('leaderboardPanel').style.display = 'none';
        this.isVisible = false;
        
        const btn = document.getElementById('leaderboardBtn');
        btn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        btn.style.color = '#fff';
    }

    requestLeaderboard() {
        this.game.socket.emit('getLeaderboard');
    }

    updateLeaderboardDisplay() {
        const leaderboardList = document.getElementById('leaderboardList');
        if (!leaderboardList) return;

        leaderboardList.innerHTML = '';

        this.leaderboardData.forEach((player, index) => {
            const playerDiv = document.createElement('div');
            playerDiv.style.cssText = `
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px;
                margin: 10px 0;
                background: ${this.getRankColor(index)};
                border-radius: 10px;
                border: 2px solid ${this.getRankBorderColor(index)};
                color: ${index < 3 ? '#000' : '#fff'};
                font-weight: bold;
            `;

            const rankIcon = this.getRankIcon(index);
            const isCurrentPlayer = player.name === this.game.player?.name;
            
            playerDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 24px;">${rankIcon}</span>
                    <div>
                        <div style="font-size: 18px; ${isCurrentPlayer ? 'text-decoration: underline;' : ''}">${player.name}</div>
                        <div style="font-size: 14px; opacity: 0.8;">Score: ${player.score}</div>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div>💰 $${player.money}</div>
                    <div>🧠 ${player.brainrots}</div>
                </div>
            `;

            leaderboardList.appendChild(playerDiv);
        });

        // Add current player if not in top 10
        const currentPlayer = this.game.player;
        if (currentPlayer && !this.leaderboardData.find(p => p.name === currentPlayer.name)) {
            const currentPlayerDiv = document.createElement('div');
            currentPlayerDiv.style.cssText = `
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px;
                margin: 20px 0 10px 0;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                border: 2px solid #4ecdc4;
                color: #fff;
                font-weight: bold;
            `;

            const currentScore = currentPlayer.money + (currentPlayer.brainrots.length * 100);
            
            currentPlayerDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 24px;">👤</span>
                    <div>
                        <div style="font-size: 18px; text-decoration: underline;">Você: ${currentPlayer.name}</div>
                        <div style="font-size: 14px; opacity: 0.8;">Score: ${currentScore}</div>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div>💰 $${currentPlayer.money}</div>
                    <div>🧠 ${currentPlayer.brainrots.length}</div>
                </div>
            `;

            leaderboardList.appendChild(currentPlayerDiv);
        }
    }

    getRankIcon(index) {
        const icons = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
        return icons[index] || '📍';
    }

    getRankColor(index) {
        const colors = [
            'linear-gradient(135deg, #ffd700, #ffed4e)', // Gold
            'linear-gradient(135deg, #c0c0c0, #e8e8e8)', // Silver
            'linear-gradient(135deg, #cd7f32, #daa520)', // Bronze
            'rgba(255, 255, 255, 0.2)',
            'rgba(255, 255, 255, 0.15)',
            'rgba(255, 255, 255, 0.1)',
            'rgba(255, 255, 255, 0.08)',
            'rgba(255, 255, 255, 0.06)',
            'rgba(255, 255, 255, 0.04)',
            'rgba(255, 255, 255, 0.02)'
        ];
        return colors[index] || 'rgba(255, 255, 255, 0.02)';
    }

    getRankBorderColor(index) {
        const colors = ['#ffd700', '#c0c0c0', '#cd7f32'];
        return colors[index] || 'rgba(255, 255, 255, 0.2)';
    }

    showGameEvent(message) {
        // Create floating notification for game events
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: absolute;
            top: 120px;
            right: 20px;
            background: rgba(0, 0, 0, 0.9);
            color: #ffd700;
            padding: 15px 20px;
            border-radius: 10px;
            border: 2px solid #ffd700;
            font-weight: bold;
            z-index: 400;
            animation: slideInRight 0.5s ease-out;
            max-width: 300px;
        `;

        notification.textContent = message;

        // Add slide animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);

        document.getElementById('ui').appendChild(notification);

        // Remove after 5 seconds
        setTimeout(() => {
            notification.remove();
            style.remove();
        }, 5000);
    }

    dispose() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
    }
}
