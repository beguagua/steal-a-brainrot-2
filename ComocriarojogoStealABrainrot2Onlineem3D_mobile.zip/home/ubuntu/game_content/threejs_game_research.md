# Pesquisa sobre Three.js para Desenvolvimento de Jogos 3D

## Three.js Overview
- **Versão atual**: r180
- **Tipo**: Biblioteca JavaScript 3D para web
- **Base**: WebGL
- **Recursos**: Renderização 3D, animações, física, materiais, texturas

## Capacidades para Jogos
- Renderização 3D em tempo real no navegador
- Suporte a geometrias complexas
- Sistema de materiais e texturas avançado
- Animações e física
- Compatibilidade com WebGL
- Comunidade ativa e recursos educacionais

## Recursos Educacionais Encontrados
- **Three.js Journey**: Curso completo (93 horas de vídeo)
- **SimonDev Game Development**: Curso específico para jogos com Three.js
- **Documentação oficial**: Exemplos e tutoriais
- **MDN Web Docs**: Guias básicos para começar

## Vantagens para "Steal A Brainrot 2"
- Execução direta no navegador (sem plugins)
- Performance adequada para jogos 3D
- Flexibilidade para mecânicas customizadas
- Suporte a multiplayer via WebSockets
- Facilidade de distribuição (apenas URL)

## Próximos Passos
- Verificar Babylon.js como alternativa
- Pesquisar sobre multiplayer/networking
- Definir arquitetura do jogo
