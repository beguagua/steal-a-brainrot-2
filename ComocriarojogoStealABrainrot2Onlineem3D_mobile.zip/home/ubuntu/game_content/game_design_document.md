_# Game Design Document: Steal A Brainrot 2_

## 1. Visão Geral

**Título:** Steal A Brainrot 2

**Conceito:** Um jogo online multiplayer 3D onde os jogadores constroem e defendem suas bases, colecionam personagens "Brainrot" e roubam de outros jogadores. O jogo expande o original "Steal Brainrot Online" com gráficos 3D, construção de base mais complexa e interação social aprimorada.

**Gênero:** Multiplayer, Casual, Estratégia, Ação

**Público-alvo:** Jogadores do "Steal Brainrot Online" original, fãs da cultura de memes e jogadores casuais que gostam de jogos multiplayer e de dedução social.

## 2. Mecânicas de Jogo

O ciclo de jogo principal consiste em:

- **Coletar:** Os jogadores adquirem Brainrots comprando-os em um mercado central ou roubando-os de outros jogadores.
- **Construir e Defender:** Os jogadores projetam e constroem suas bases 3D para proteger seus Brainrots. Isso inclui a colocação de paredes, armadilhas e outras estruturas defensivas.
- **Roubar:** Os jogadores podem se infiltrar nas bases de outros jogadores para roubar seus Brainrots. Isso envolverá navegar pelo ambiente 3D, evitar armadilhas e escapar antes de ser pego.
- **Melhorar:** Os jogadores usam a renda gerada por seus Brainrots para melhorar sua base, comprar defesas melhores e adquirir Brainrots mais poderosos.

## 3. Recursos Principais

| Recurso | Descrição |
| :--- | :--- |
| **Ambiente 3D** | Mundo totalmente 3D construído com um motor baseado na web (Three.js). |
| **Construção de Base** | Os jogadores podem projetar e construir livremente suas bases no espaço 3D. |
| **Multiplayer** | Interação em tempo real com outros jogadores, incluindo cooperação e competição. |
| **Coleção de Brainrots** | Uma variedade de personagens Brainrot novos e clássicos para colecionar. |
| **Armadilhas e Defesas** | Uma ampla gama de armadilhas e mecanismos de defesa para proteger as bases. |
| **Customização** | Os jogadores podem personalizar seus avatares. |
| **Leaderboards** | Rankings globais e regionais para acompanhar o progresso e a riqueza dos jogadores. |

## 4. Arquitetura Técnica

**Frontend:**
- **Motor:** Three.js
- **Linguagem:** JavaScript/TypeScript
- **UI:** HTML/CSS

**Backend:**
- **Linguagem:** Node.js
- **Framework:** Express.js
- **Banco de Dados:** MongoDB
- **Comunicação em tempo real:** WebSockets (Socket.IO)

**Implantação:**
- **Frontend:** Site estático em um provedor de nuvem.
- **Backend:** Servidor em nuvem.

