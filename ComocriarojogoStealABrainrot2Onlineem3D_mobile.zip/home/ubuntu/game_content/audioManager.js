export class AudioManager {
    constructor() {
        this.audioContext = null;
        this.sounds = new Map();
        this.musicVolume = 0.5;
        this.sfxVolume = 0.7;
        this.currentMusic = null;
        this.isInitialized = false;
        
        // Initialize audio context on first user interaction
        this.initializeAudio();
    }

    async initializeAudio() {
        try {
            // Create audio context
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            // Create gain nodes for volume control
            this.musicGain = this.audioContext.createGain();
            this.sfxGain = this.audioContext.createGain();
            
            this.musicGain.connect(this.audioContext.destination);
            this.sfxGain.connect(this.audioContext.destination);
            
            this.musicGain.gain.value = this.musicVolume;
            this.sfxGain.gain.value = this.sfxVolume;
            
            // Generate procedural sounds
            this.generateProceduralSounds();
            
            this.isInitialized = true;
            console.log('Sistema de áudio inicializado');
        } catch (error) {
            console.error('Erro ao inicializar áudio:', error);
        }
    }

    generateProceduralSounds() {
        // Generate coin collect sound
        this.sounds.set('coin_collect', this.generateCoinSound());
        
        // Generate steal sound
        this.sounds.set('steal_attempt', this.generateStealSound());
        
        // Generate success sound
        this.sounds.set('success', this.generateSuccessSound());
        
        // Generate error sound
        this.sounds.set('error', this.generateErrorSound());
        
        // Generate footstep sound
        this.sounds.set('footstep', this.generateFootstepSound());
        
        // Generate build sound
        this.sounds.set('build', this.generateBuildSound());
        
        // Generate shield sound
        this.sounds.set('shield', this.generateShieldSound());
        
        // Generate ambient music
        this.sounds.set('ambient_music', this.generateAmbientMusic());
        
        // Generate brainrot spawn sound
        this.sounds.set('brainrot_spawn', this.generateBrainrotSpawnSound());
        
        // Generate chat notification
        this.sounds.set('chat_notification', this.generateChatSound());
    }

    generateCoinSound() {
        const duration = 0.3;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Coin sound: high frequency with decay
            const freq = 800 + Math.sin(t * 20) * 200;
            const envelope = Math.exp(-t * 8);
            data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * 0.3;
        }

        return buffer;
    }

    generateStealSound() {
        const duration = 0.5;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Sneaky sound: low frequency with wobble
            const freq = 200 + Math.sin(t * 15) * 50;
            const envelope = Math.sin(t * Math.PI / duration);
            data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * 0.2;
        }

        return buffer;
    }

    generateSuccessSound() {
        const duration = 0.6;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Success sound: ascending notes
            const freq = 440 + t * 220;
            const envelope = Math.exp(-t * 3);
            data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * 0.4;
        }

        return buffer;
    }

    generateErrorSound() {
        const duration = 0.4;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Error sound: descending buzz
            const freq = 300 - t * 150;
            const envelope = Math.exp(-t * 5);
            const buzz = Math.random() * 0.3 + 0.7;
            data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * buzz * 0.3;
        }

        return buffer;
    }

    generateFootstepSound() {
        const duration = 0.1;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Footstep: short noise burst
            const noise = (Math.random() - 0.5) * 2;
            const envelope = Math.exp(-t * 50);
            data[i] = noise * envelope * 0.1;
        }

        return buffer;
    }

    generateBuildSound() {
        const duration = 0.3;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Build sound: construction-like
            const freq = 150 + Math.sin(t * 30) * 50;
            const envelope = Math.sin(t * Math.PI / duration);
            const noise = (Math.random() - 0.5) * 0.2;
            data[i] = (Math.sin(2 * Math.PI * freq * t) + noise) * envelope * 0.25;
        }

        return buffer;
    }

    generateShieldSound() {
        const duration = 0.8;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Shield sound: magical shimmer
            const freq = 600 + Math.sin(t * 10) * 200;
            const envelope = Math.exp(-t * 2);
            const shimmer = Math.sin(t * 40) * 0.3;
            data[i] = (Math.sin(2 * Math.PI * freq * t) + shimmer) * envelope * 0.3;
        }

        return buffer;
    }

    generateBrainrotSpawnSound() {
        const duration = 0.7;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Brainrot spawn: quirky digital sound
            const freq = 400 + Math.sin(t * 25) * 150;
            const envelope = Math.sin(t * Math.PI / duration);
            const digital = Math.sin(t * 100) * 0.2;
            data[i] = (Math.sin(2 * Math.PI * freq * t) + digital) * envelope * 0.35;
        }

        return buffer;
    }

    generateChatSound() {
        const duration = 0.2;
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(1, duration * sampleRate, sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            // Chat notification: gentle ping
            const freq = 800;
            const envelope = Math.exp(-t * 10);
            data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * 0.2;
        }

        return buffer;
    }

    generateAmbientMusic() {
        const duration = 30; // 30 seconds loop
        const sampleRate = this.audioContext.sampleRate;
        const buffer = this.audioContext.createBuffer(2, duration * sampleRate, sampleRate);
        
        const leftChannel = buffer.getChannelData(0);
        const rightChannel = buffer.getChannelData(1);

        for (let i = 0; i < buffer.length; i++) {
            const t = i / sampleRate;
            
            // Ambient music: layered sine waves
            const bass = Math.sin(2 * Math.PI * 55 * t) * 0.1;
            const melody = Math.sin(2 * Math.PI * 220 * t + Math.sin(t * 0.5)) * 0.05;
            const harmony = Math.sin(2 * Math.PI * 330 * t + Math.sin(t * 0.3)) * 0.03;
            const pad = Math.sin(2 * Math.PI * 110 * t + Math.sin(t * 0.1)) * 0.02;
            
            const envelope = 0.5 + 0.5 * Math.sin(t * 0.1);
            
            leftChannel[i] = (bass + melody + harmony + pad) * envelope;
            rightChannel[i] = (bass + melody * 0.8 + harmony * 1.2 + pad) * envelope;
        }

        return buffer;
    }

    playSound(soundName, volume = 1.0, pitch = 1.0) {
        if (!this.isInitialized || this.audioContext.state === 'suspended') {
            // Try to resume audio context
            this.audioContext.resume();
        }

        const buffer = this.sounds.get(soundName);
        if (!buffer) {
            console.warn(`Som não encontrado: ${soundName}`);
            return;
        }

        try {
            const source = this.audioContext.createBufferSource();
            const gainNode = this.audioContext.createGain();
            
            source.buffer = buffer;
            source.playbackRate.value = pitch;
            
            gainNode.gain.value = volume;
            
            source.connect(gainNode);
            gainNode.connect(this.sfxGain);
            
            source.start();
            
            // Clean up after sound finishes
            source.onended = () => {
                source.disconnect();
                gainNode.disconnect();
            };
        } catch (error) {
            console.error(`Erro ao tocar som ${soundName}:`, error);
        }
    }

    playMusic(musicName, loop = true) {
        if (this.currentMusic) {
            this.stopMusic();
        }

        const buffer = this.sounds.get(musicName);
        if (!buffer) {
            console.warn(`Música não encontrada: ${musicName}`);
            return;
        }

        try {
            this.currentMusic = this.audioContext.createBufferSource();
            this.currentMusic.buffer = buffer;
            this.currentMusic.loop = loop;
            
            this.currentMusic.connect(this.musicGain);
            this.currentMusic.start();
        } catch (error) {
            console.error(`Erro ao tocar música ${musicName}:`, error);
        }
    }

    stopMusic() {
        if (this.currentMusic) {
            try {
                this.currentMusic.stop();
                this.currentMusic.disconnect();
            } catch (error) {
                console.error('Erro ao parar música:', error);
            }
            this.currentMusic = null;
        }
    }

    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));
        if (this.musicGain) {
            this.musicGain.gain.value = this.musicVolume;
        }
    }

    setSFXVolume(volume) {
        this.sfxVolume = Math.max(0, Math.min(1, volume));
        if (this.sfxGain) {
            this.sfxGain.gain.value = this.sfxVolume;
        }
    }

    // Spatial audio methods
    playPositionalSound(soundName, position, listenerPosition, volume = 1.0) {
        if (!this.isInitialized) return;

        const distance = Math.sqrt(
            Math.pow(position.x - listenerPosition.x, 2) +
            Math.pow(position.z - listenerPosition.z, 2)
        );

        // Calculate volume based on distance
        const maxDistance = 50;
        const distanceVolume = Math.max(0, 1 - (distance / maxDistance));
        
        // Calculate stereo panning
        const deltaX = position.x - listenerPosition.x;
        const pan = Math.max(-1, Math.min(1, deltaX / 20));
        
        this.playSoundWithPanning(soundName, volume * distanceVolume, pan);
    }

    playSoundWithPanning(soundName, volume = 1.0, pan = 0) {
        const buffer = this.sounds.get(soundName);
        if (!buffer) return;

        try {
            const source = this.audioContext.createBufferSource();
            const gainNode = this.audioContext.createGain();
            const pannerNode = this.audioContext.createStereoPanner();
            
            source.buffer = buffer;
            gainNode.gain.value = volume;
            pannerNode.pan.value = pan;
            
            source.connect(gainNode);
            gainNode.connect(pannerNode);
            pannerNode.connect(this.sfxGain);
            
            source.start();
            
            source.onended = () => {
                source.disconnect();
                gainNode.disconnect();
                pannerNode.disconnect();
            };
        } catch (error) {
            console.error(`Erro ao tocar som posicional ${soundName}:`, error);
        }
    }

    // Initialize audio on first user interaction
    enableAudio() {
        if (this.audioContext && this.audioContext.state === 'suspended') {
            this.audioContext.resume().then(() => {
                console.log('Áudio ativado');
                this.playMusic('ambient_music');
            });
        }
    }

    dispose() {
        this.stopMusic();
        if (this.audioContext) {
            this.audioContext.close();
        }
        this.sounds.clear();
    }
}
