# Análise do Jogo "Steal Brainrot Online"

## Conceito Principal

O "Steal Brainrot Online" é um jogo multiplayer casual baseado em roubo e coleta de memes "Brainrot" (como Tralalero Tralala e Cappuccino Assassino). O conceito central gira em torno da cultura de memes "brainrot" italiana que emergiu em 2025, caracterizada por imagens surreais e absurdas de criaturas geradas por IA.

## Mecânicas Principais

### Sistema de Coleta
- **Compra**: Jogadores podem comprar Brainrots com dinheiro do "tapete vermelho"
- **Roubo**: Invasão de bases de outros jogadores para roubar Brainrots
- **Geração de Renda**: Brainrots coletados geram dinheiro passivamente quando colocados em pedestais

### Sistema de Base
- **Defesas**: Fechaduras e escudos temporários (60 segundos)
- **Visibilidade**: Outras pessoas podem ver sua coleção
- **Proteção**: Necessidade de equilibrar segurança e crescimento

### Mecânicas de Roubo
- **Processo**: Entrar na base, carregar o Brainrot, levar para sua base
- **Penalidades**: Movimento mais lento, sem uso de itens, alerta ao dono
- **Perseguição**: Donos podem perseguir e recuperar com martelo
- **Escape**: Botão home (G) para teleporte de emergência

### Sistema de Progressão
- **Reinicialização**: Sistema de "rebirth" para recompensas de longo prazo
- **Boosters**: Itens para melhorar performance
- **Leilões**: Competir por entregas especiais
- **Leaderboard**: Ranking competitivo

## Controles
- **WASD**: Movimento
- **Espaço**: Pular
- **E**: Interagir
- **G**: Voltar para casa

## Elementos Visuais e Temáticos
- **Estética**: Colorida, cartoonesca, baseada em memes
- **Personagens**: Criaturas absurdas e memes italianos
- **Ambiente**: Bases personalizáveis com pedestais para exibição

## Aspectos Sociais
- **Multiplayer**: Jogadores globais em tempo real
- **Tensão Social**: Vigilância mútua e decisões estratégicas
- **Competição**: Equilíbrio entre ganância e cautela
