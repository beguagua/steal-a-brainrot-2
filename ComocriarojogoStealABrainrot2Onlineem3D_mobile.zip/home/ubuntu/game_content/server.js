const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Game state
const gameState = {
    players: new Map(),
    brainrots: new Map(),
    bases: new Map(),
    marketItems: []
};

// Player class
class Player {
    constructor(id, name) {
        this.id = id;
        this.name = name;
        this.position = { x: Math.random() * 100, y: 0, z: Math.random() * 100 };
        this.money = 1000;
        this.brainrots = [];
        this.base = null;
        this.isCarrying = null;
        this.health = 100;
        this.lastUpdate = Date.now();
    }

    update() {
        // Generate passive income from brainrots
        const income = this.brainrots.length * 10;
        this.money += income;
        this.lastUpdate = Date.now();
    }
}

// Brainrot class
class Brainrot {
    constructor(id, type, owner) {
        this.id = id;
        this.type = type;
        this.owner = owner;
        this.position = { x: 0, y: 0, z: 0 };
        this.value = this.getValueByType(type);
        this.isStolen = false;
    }

    getValueByType(type) {
        const values = {
            'tralalero': 100,
            'cappuccino': 150,
            'bombardino': 200,
            'tung_sahur': 250,
            'rare_meme': 500
        };
        return values[type] || 100;
    }
}

// Base class
class Base {
    constructor(playerId) {
        this.playerId = playerId;
        this.position = { x: Math.random() * 100, y: 0, z: Math.random() * 100 };
        this.structures = [];
        this.defenses = [];
        this.isLocked = false;
        this.shieldTime = 0;
    }
}

// Initialize market with some brainrots
function initializeMarket() {
    const types = ['tralalero', 'cappuccino', 'bombardino', 'tung_sahur', 'rare_meme'];
    for (let i = 0; i < 10; i++) {
        const type = types[Math.floor(Math.random() * types.length)];
        gameState.marketItems.push({
            id: `market_${i}`,
            type: type,
            price: Math.floor(Math.random() * 300) + 100
        });
    }
}

// Socket connection handling
io.on('connection', (socket) => {
    console.log(`Jogador conectado: ${socket.id}`);

    // Player joins game
    socket.on('joinGame', (playerName) => {
        const player = new Player(socket.id, playerName || `Player_${socket.id.substring(0, 6)}`);
        const base = new Base(socket.id);
        
        gameState.players.set(socket.id, player);
        gameState.bases.set(socket.id, base);
        
        player.base = base;

        // Send initial game state to new player
        socket.emit('gameState', {
            player: player,
            players: Array.from(gameState.players.values()),
            bases: Array.from(gameState.bases.values()),
            marketItems: gameState.marketItems
        });

        // Broadcast new player to others
        socket.broadcast.emit('playerJoined', player);
        
        // Update player count
        io.emit('playerCount', gameState.players.size);
    });

    // Player movement
    socket.on('playerMove', (position) => {
        const player = gameState.players.get(socket.id);
        if (player) {
            player.position = position;
            socket.broadcast.emit('playerMoved', {
                playerId: socket.id,
                position: position
            });
        }
    });

    // Buy brainrot from market
    socket.on('buyBrainrot', (itemId) => {
        const player = gameState.players.get(socket.id);
        const item = gameState.marketItems.find(i => i.id === itemId);
        
        if (player && item && player.money >= item.price) {
            player.money -= item.price;
            
            const brainrot = new Brainrot(`br_${Date.now()}`, item.type, socket.id);
            brainrot.position = { ...player.base.position };
            
            player.brainrots.push(brainrot);
            gameState.brainrots.set(brainrot.id, brainrot);
            
            // Remove item from market
            gameState.marketItems = gameState.marketItems.filter(i => i.id !== itemId);
            
            // Add new random item to market
            const types = ['tralalero', 'cappuccino', 'bombardino', 'tung_sahur', 'rare_meme'];
            const newType = types[Math.floor(Math.random() * types.length)];
            gameState.marketItems.push({
                id: `market_${Date.now()}`,
                type: newType,
                price: Math.floor(Math.random() * 300) + 100
            });

            socket.emit('brainrotPurchased', {
                brainrot: brainrot,
                newMoney: player.money,
                marketItems: gameState.marketItems
            });

            socket.broadcast.emit('playerUpdated', player);
        }
    });

    // Attempt to steal brainrot
    socket.on('attemptSteal', (targetPlayerId) => {
        const thief = gameState.players.get(socket.id);
        const target = gameState.players.get(targetPlayerId);
        const targetBase = gameState.bases.get(targetPlayerId);

        if (thief && target && targetBase && !targetBase.isLocked && target.brainrots.length > 0) {
            // Check if thief is close enough to target base
            const distance = Math.sqrt(
                Math.pow(thief.position.x - targetBase.position.x, 2) +
                Math.pow(thief.position.z - targetBase.position.z, 2)
            );

            if (distance < 10) { // Within stealing range
                const stolenBrainrot = target.brainrots.pop();
                if (stolenBrainrot) {
                    thief.isCarrying = stolenBrainrot;
                    stolenBrainrot.isStolen = true;

                    socket.emit('stealSuccess', stolenBrainrot);
                    
                    // Alert the target player
                    io.to(targetPlayerId).emit('baseRaided', {
                        thiefId: socket.id,
                        thiefName: thief.name,
                        stolenBrainrot: stolenBrainrot
                    });

                    socket.broadcast.emit('playerUpdated', thief);
                    socket.broadcast.emit('playerUpdated', target);
                }
            }
        }
    });

    // Complete steal (bring brainrot to own base)
    socket.on('completeSteal', () => {
        const player = gameState.players.get(socket.id);
        if (player && player.isCarrying) {
            const brainrot = player.isCarrying;
            brainrot.owner = socket.id;
            brainrot.isStolen = false;
            brainrot.position = { ...player.base.position };
            
            player.brainrots.push(brainrot);
            player.isCarrying = null;

            socket.emit('stealCompleted', brainrot);
            socket.broadcast.emit('playerUpdated', player);
            
            // Broadcast to all players that a steal was completed
            io.emit('gameEvent', {
                type: 'stealCompleted',
                thiefName: player.name,
                brainrotType: brainrot.type
            });
        }
    });

    // Activate base shield
    socket.on('activateShield', () => {
        const base = gameState.bases.get(socket.id);
        const player = gameState.players.get(socket.id);
        
        if (base && player && player.money >= 100) {
            player.money -= 100;
            base.shieldTime = Date.now() + 60000; // 60 seconds
            
            socket.emit('shieldActivated', {
                newMoney: player.money,
                shieldTime: base.shieldTime
            });
        }
    });

    // Chat message
    socket.on('chatMessage', (message) => {
        const player = gameState.players.get(socket.id);
        if (player) {
            io.emit('chatMessage', {
                playerId: socket.id,
                playerName: player.name,
                message: message,
                timestamp: Date.now()
            });
        }
    });

    // Get leaderboard
    socket.on('getLeaderboard', () => {
        const leaderboard = Array.from(gameState.players.values())
            .map(player => ({
                name: player.name,
                money: player.money,
                brainrots: player.brainrots.length,
                score: player.money + (player.brainrots.length * 100)
            }))
            .sort((a, b) => b.score - a.score)
            .slice(0, 10);

        socket.emit('leaderboard', leaderboard);
    });

    // Build structure
    socket.on('buildStructure', (data) => {
        const player = gameState.players.get(socket.id);
        const base = gameState.bases.get(socket.id);
        
        if (player && base && player.money >= data.cost) {
            player.money -= data.cost;
            
            base.structures.push({
                type: data.type,
                position: data.position,
                timestamp: Date.now()
            });

            socket.emit('buildSuccess', {
                newMoney: player.money,
                structure: base.structures[base.structures.length - 1]
            });

            socket.broadcast.emit('playerUpdated', player);
        } else {
            socket.emit('buildFailed', 'Dinheiro insuficiente ou base não encontrada');
        }
    });

    // Player disconnect
    socket.on('disconnect', () => {
        console.log(`Jogador desconectado: ${socket.id}`);
        
        gameState.players.delete(socket.id);
        gameState.bases.delete(socket.id);
        
        // Remove player's brainrots
        for (const [id, brainrot] of gameState.brainrots) {
            if (brainrot.owner === socket.id) {
                gameState.brainrots.delete(id);
            }
        }

        socket.broadcast.emit('playerLeft', socket.id);
        io.emit('playerCount', gameState.players.size);
    });
});

// Game loop - update players and game state
setInterval(() => {
    for (const player of gameState.players.values()) {
        player.update();
    }
    
    // Update shield timers
    for (const base of gameState.bases.values()) {
        if (base.shieldTime > 0 && Date.now() > base.shieldTime) {
            base.shieldTime = 0;
        }
    }
}, 1000);

// Initialize market
initializeMarket();

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/status', (req, res) => {
    res.json({
        players: gameState.players.size,
        brainrots: gameState.brainrots.size,
        uptime: process.uptime()
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`🎮 Steal A Brainrot 2 servidor rodando na porta ${PORT}`);
    console.log(`🌐 Acesse: http://localhost:${PORT}`);
});

module.exports = { app, server, io };
