import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { GameplayManager } from './gameplay.js';
import { TextureManager } from './textureManager.js';
import { AudioManager } from './audioManager.js';
import { LeaderboardManager } from './leaderboard.js';
import { MobileControls } from './mobile_controls.js';

class Game {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.socket = null;
        this.player = null;
        this.players = new Map();
        this.brainrots = new Map();
        this.bases = new Map();
        this.world = null;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.keys = {};
        this.gameState = 'loading';
        this.clock = new THREE.Clock();
        this.gameplayManager = null;
        this.textureManager = new TextureManager();
        this.audioManager = new AudioManager();
        this.leaderboardManager = null;
        this.mobileControls = null;
        
        this.init();
    }

    async init() {
        this.setupScene();
        this.setupLighting();
        this.setupControls();
        this.setupEventListeners();
        
        // Load textures
        await this.textureManager.loadAllTextures();
        
        this.createWorld();
        this.connectToServer();
        this.setupUI();
        
        // Initialize gameplay manager
        this.gameplayManager = new GameplayManager(this);
        
        // Initialize leaderboard manager
        this.leaderboardManager = new LeaderboardManager(this);

        // Initialize mobile controls
        this.mobileControls = new MobileControls(this);
        
        // Start game loop
        this.animate();
        
        // Hide loading screen
        setTimeout(() => {
            document.getElementById('loadingScreen').style.display = 'none';
            this.gameState = 'playing';
            
            // Enable audio and start ambient music
            this.audioManager.enableAudio();
        }, 2000);
    }

    setupScene() {
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB); // Sky blue
        this.scene.fog = new THREE.Fog(0x87CEEB, 50, 200);

        // Create camera
        this.camera = new THREE.PerspectiveCamera(
            75,
            window.innerWidth / window.innerHeight,
            0.1,
            1000
        );
        this.camera.position.set(0, 20, 30);

        // Create renderer
        this.renderer = new THREE.WebGLRenderer({
            canvas: document.getElementById('gameCanvas'),
            antialias: true
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    }

    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
        this.scene.add(ambientLight);

        // Directional light (sun)
        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(50, 50, 50);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 200;
        directionalLight.shadow.camera.left = -50;
        directionalLight.shadow.camera.right = 50;
        directionalLight.shadow.camera.top = 50;
        directionalLight.shadow.camera.bottom = -50;
        this.scene.add(directionalLight);

        // Point lights for atmosphere
        const pointLight1 = new THREE.PointLight(0xff6b6b, 0.5, 30);
        pointLight1.position.set(-20, 10, -20);
        this.scene.add(pointLight1);

        const pointLight2 = new THREE.PointLight(0x4ecdc4, 0.5, 30);
        pointLight2.position.set(20, 10, 20);
        this.scene.add(pointLight2);
    }

    setupControls() {
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.maxPolarAngle = Math.PI / 2.2;
        this.controls.minDistance = 10;
        this.controls.maxDistance = 100;
    }

    setupEventListeners() {
        // Window resize
        window.addEventListener('resize', () => this.onWindowResize());
        
        // Mouse events
        this.renderer.domElement.addEventListener('click', (event) => this.onMouseClick(event));
        this.renderer.domElement.addEventListener('mousemove', (event) => this.onMouseMove(event));
        
        // Keyboard events
        document.addEventListener('keydown', (event) => this.onKeyDown(event));
        document.addEventListener('keyup', (event) => this.onKeyUp(event));
    }

    createWorld() {
        // Create ground
        const groundGeometry = new THREE.PlaneGeometry(200, 200);
        const groundMaterial = this.textureManager.createGroundMaterial();
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);

        // Create grid helper
        const gridHelper = new THREE.GridHelper(200, 50, 0x000000, 0x000000);
        gridHelper.material.opacity = 0.2;
        gridHelper.material.transparent = true;
        this.scene.add(gridHelper);

        // Create central market area
        this.createMarketArea();
        
        // Create some decorative elements
        this.createDecorations();
    }

    createMarketArea() {
        // Market platform
        const platformGeometry = new THREE.CylinderGeometry(15, 15, 2, 16);
        const platformMaterial = new THREE.MeshLambertMaterial({ color: 0xffd700 });
        const platform = new THREE.Mesh(platformGeometry, platformMaterial);
        platform.position.set(0, 1, 0);
        platform.castShadow = true;
        platform.receiveShadow = true;
        this.scene.add(platform);

        // Market sign
        const signGeometry = new THREE.BoxGeometry(8, 4, 0.5);
        const signMaterial = new THREE.MeshLambertMaterial({ color: 0x8B4513 });
        const sign = new THREE.Mesh(signGeometry, signMaterial);
        sign.position.set(0, 8, 0);
        sign.castShadow = true;
        this.scene.add(sign);

        // Add text to sign (simplified)
        const textGeometry = new THREE.PlaneGeometry(8, 4);
        const textMaterial = this.textureManager.createMarketSignMaterial();
        const textMesh = new THREE.Mesh(textGeometry, textMaterial);
        textMesh.position.set(0, 8, 0.3);
        this.scene.add(textMesh);
    }

    createDecorations() {
        // Create some random trees/obstacles
        for (let i = 0; i < 20; i++) {
            const treeGeometry = new THREE.ConeGeometry(2, 8, 8);
            const treeMaterial = new THREE.MeshLambertMaterial({ color: 0x228B22 });
            const tree = new THREE.Mesh(treeGeometry, treeMaterial);
            
            tree.position.set(
                (Math.random() - 0.5) * 180,
                4,
                (Math.random() - 0.5) * 180
            );
            tree.castShadow = true;
            this.scene.add(tree);

            // Tree trunk
            const trunkGeometry = new THREE.CylinderGeometry(0.5, 0.8, 4);
            const trunkMaterial = new THREE.MeshLambertMaterial({ color: 0x8B4513 });
            const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
            trunk.position.copy(tree.position);
            trunk.position.y = 2;
            trunk.castShadow = true;
            this.scene.add(trunk);
        }

        // Create some rocks
        for (let i = 0; i < 15; i++) {
            const rockGeometry = new THREE.DodecahedronGeometry(Math.random() * 2 + 1);
            const rockMaterial = new THREE.MeshLambertMaterial({ color: 0x696969 });
            const rock = new THREE.Mesh(rockGeometry, rockMaterial);
            
            rock.position.set(
                (Math.random() - 0.5) * 160,
                1,
                (Math.random() - 0.5) * 160
            );
            rock.castShadow = true;
            rock.receiveShadow = true;
            this.scene.add(rock);
        }
    }

    createPlayer(playerData) {
        // Create player representation
        const playerGroup = new THREE.Group();
        
        // Player body
        const bodyGeometry = new THREE.CapsuleGeometry(1, 3);
        const bodyMaterial = new THREE.MeshLambertMaterial({ 
            color: playerData.id === this.socket.id ? 0x00ff00 : 0xff6b6b 
        });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        body.position.y = 2;
        body.castShadow = true;
        playerGroup.add(body);

        // Player head
        const headGeometry = new THREE.SphereGeometry(0.8);
        const headMaterial = new THREE.MeshLambertMaterial({ color: 0xffdbac });
        const head = new THREE.Mesh(headGeometry, headMaterial);
        head.position.y = 4.5;
        head.castShadow = true;
        playerGroup.add(head);

        // Player name tag
        const nameGeometry = new THREE.PlaneGeometry(4, 1);
        const nameMaterial = new THREE.MeshBasicMaterial({ 
            color: 0xffffff,
            transparent: true,
            opacity: 0.8
        });
        const nameTag = new THREE.Mesh(nameGeometry, nameMaterial);
        nameTag.position.y = 6;
        nameTag.lookAt(this.camera.position);
        playerGroup.add(nameTag);

        playerGroup.position.set(
            playerData.position.x,
            playerData.position.y,
            playerData.position.z
        );

        this.scene.add(playerGroup);
        this.players.set(playerData.id, {
            data: playerData,
            mesh: playerGroup,
            nameTag: nameTag
        });

        return playerGroup;
    }

    createBrainrot(brainrotData) {
        // Create brainrot representation
        const brainrotGroup = new THREE.Group();
        
        // Main body with specific texture based on type
        const bodyGeometry = new THREE.OctahedronGeometry(1.5);
        const bodyMaterial = this.textureManager.createBrainrotMaterial(brainrotData.type);
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        body.position.y = 2;
        body.castShadow = true;
        brainrotGroup.add(body);

        // Floating animation
        const floatAnimation = (time) => {
            body.position.y = 2 + Math.sin(time * 2) * 0.5;
            body.rotation.y += 0.01;
        };

        brainrotGroup.position.set(
            brainrotData.position.x,
            brainrotData.position.y,
            brainrotData.position.z
        );

        brainrotGroup.userData = { 
            floatAnimation: floatAnimation,
            brainrotData: brainrotData
        };

        this.scene.add(brainrotGroup);
        this.brainrots.set(brainrotData.id, brainrotGroup);

        return brainrotGroup;
    }

    createBase(baseData) {
        // Create base representation
        const baseGroup = new THREE.Group();
        
        // Get building materials
        const materials = this.textureManager.createBuildingMaterials();
        
        // Base platform
        const platformGeometry = new THREE.CylinderGeometry(8, 8, 1, 16);
        const platform = new THREE.Mesh(platformGeometry, materials.base_platform);
        platform.position.y = 0.5;
        platform.castShadow = true;
        platform.receiveShadow = true;
        baseGroup.add(platform);

        // Base walls
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const wallGeometry = new THREE.BoxGeometry(2, 4, 0.5);
            const wall = new THREE.Mesh(wallGeometry, materials.wall);
            
            wall.position.set(
                Math.cos(angle) * 7,
                2,
                Math.sin(angle) * 7
            );
            wall.rotation.y = angle;
            wall.castShadow = true;
            baseGroup.add(wall);
        }

        // Brainrot pedestals
        for (let i = 0; i < 4; i++) {
            const angle = (i / 4) * Math.PI * 2;
            const pedestalGeometry = new THREE.CylinderGeometry(1, 1.2, 2);
            const pedestal = new THREE.Mesh(pedestalGeometry, materials.pedestal);
            
            pedestal.position.set(
                Math.cos(angle) * 4,
                1,
                Math.sin(angle) * 4
            );
            pedestal.castShadow = true;
            baseGroup.add(pedestal);
        }

        baseGroup.position.set(
            baseData.position.x,
            baseData.position.y,
            baseData.position.z
        );

        this.scene.add(baseGroup);
        this.bases.set(baseData.playerId, baseGroup);

        return baseGroup;
    }

    connectToServer() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            console.log('Conectado ao servidor');
            this.socket.emit('joinGame', 'Player');
        });

        this.socket.on('gameState', (data) => {
            this.player = data.player;
            
            // Create other players
            data.players.forEach(player => {
                if (player.id !== this.socket.id) {
                    this.createPlayer(player);
                }
            });

            // Create bases
            data.bases.forEach(base => {
                this.createBase(base);
            });

            // Update UI
            this.updateUI();
        });

        this.socket.on('playerJoined', (player) => {
            this.createPlayer(player);
        });

        this.socket.on('playerLeft', (playerId) => {
            const playerObj = this.players.get(playerId);
            if (playerObj) {
                this.scene.remove(playerObj.mesh);
                this.players.delete(playerId);
            }
            
            const base = this.bases.get(playerId);
            if (base) {
                this.scene.remove(base);
                this.bases.delete(playerId);
            }
        });

        this.socket.on('playerMoved', (data) => {
            const playerObj = this.players.get(data.playerId);
            if (playerObj) {
                playerObj.mesh.position.set(
                    data.position.x,
                    data.position.y,
                    data.position.z
                );
            }
        });

        this.socket.on('playerCount', (count) => {
            document.getElementById('playerCount').textContent = count;
        });

        this.socket.on('brainrotPurchased', (data) => {
            this.audioManager.playSound('coin_collect');
            this.updateUI();
        });

        this.socket.on('stealSuccess', (data) => {
            this.audioManager.playSound('steal_attempt');
        });

        this.socket.on('stealCompleted', (data) => {
            this.audioManager.playSound('success');
        });

        this.socket.on('baseRaided', (data) => {
            this.audioManager.playSound('error');
        });

        this.socket.on('shieldActivated', (data) => {
            this.audioManager.playSound('shield');
        });

        this.socket.on('chatMessage', (data) => {
            this.addChatMessage(data);
            this.audioManager.playSound('chat_notification', 0.3);
        });
    }

    setupUI() {
        // Build button
        document.getElementById('buildBtn').addEventListener('click', () => {
            console.log('Build mode activated');
        });

        // Shop button
        document.getElementById('shopBtn').addEventListener('click', () => {
            console.log('Shop opened');
        });

        // Steal button
        document.getElementById('stealBtn').addEventListener('click', () => {
            console.log('Steal mode activated');
        });

        // Chat button
        document.getElementById('chatBtn').addEventListener('click', () => {
            const chatPanel = document.getElementById('chatPanel');
            chatPanel.style.display = chatPanel.style.display === 'none' ? 'block' : 'none';
        });

        // Chat input
        document.getElementById('chatInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const message = e.target.value.trim();
                if (message) {
                    this.socket.emit('chatMessage', message);
                    e.target.value = '';
                }
            }
        });
    }

    updateUI() {
        if (this.player) {
            document.getElementById('money').textContent = this.player.money;
            document.getElementById('brainrots').textContent = this.player.brainrots.length;
        }
    }

    addChatMessage(data) {
        const chatMessages = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.innerHTML = `<strong>${data.playerName}:</strong> ${data.message}`;
        messageDiv.style.marginBottom = '5px';
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    onMouseClick(event) {
        // Calculate mouse position in normalized device coordinates
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

        // Raycast to detect clicks
        this.raycaster.setFromCamera(this.mouse, this.camera);
        
        // Check for intersections with clickable objects
        const intersects = this.raycaster.intersectObjects(this.scene.children, true);
        
        // Pass click to gameplay manager
        if (this.gameplayManager) {
            this.gameplayManager.handleMouseClick(event, intersects);
        }
        
        if (intersects.length > 0) {
            const clickedObject = intersects[0].object;
            console.log('Clicked object:', clickedObject);
        }
    }

    onMouseMove(event) {
        // Update mouse position for raycasting
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    }

    onKeyDown(event) {
        this.keys[event.code] = true;
        
        // Handle specific key actions
        switch(event.code) {
            case 'KeyG':
                // Go home
                if (this.player) {
                    console.log('Going home');
                }
                break;
            case 'KeyE':
                // Interact
                console.log('Interact');
                break;
        }
    }

    onKeyUp(event) {
        this.keys[event.code] = false;
    }

    handleMovement() {
        if (!this.player) return;

        const moveSpeed = 0.5;
        let moved = false;
        const newPosition = { ...this.player.position };

        if (this.keys['KeyW'] || this.keys['ArrowUp']) {
            newPosition.z -= moveSpeed;
            moved = true;
        }
        if (this.keys['KeyS'] || this.keys['ArrowDown']) {
            newPosition.z += moveSpeed;
            moved = true;
        }
        if (this.keys['KeyA'] || this.keys['ArrowLeft']) {
            newPosition.x -= moveSpeed;
            moved = true;
        }
        if (this.keys['KeyD'] || this.keys['ArrowRight']) {
            newPosition.x += moveSpeed;
            moved = true;
        }

        if (moved) {
            this.player.position = newPosition;
            this.socket.emit('playerMove', newPosition);
            
            // Play footstep sound occasionally
            if (Math.random() < 0.1) {
                this.audioManager.playSound('footstep', 0.3, 0.8 + Math.random() * 0.4);
            }
            
            // Update camera to follow player
            this.controls.target.set(newPosition.x, 0, newPosition.z);
        }
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const deltaTime = this.clock.getDelta();
        const elapsedTime = this.clock.getElapsedTime();

        if (this.gameState === 'playing') {
            this.handleMovement();
            
            // Update gameplay manager
            if (this.gameplayManager) {
                this.gameplayManager.update();
            }
        }

        // Update controls
        this.controls.update();

        // Animate brainrots
        this.brainrots.forEach(brainrot => {
            if (brainrot.userData.floatAnimation) {
                brainrot.userData.floatAnimation(elapsedTime);
            }
        });

        // Update name tags to face camera
        this.players.forEach(player => {
            if (player.nameTag) {
                player.nameTag.lookAt(this.camera.position);
            }
        });

        // Render
        this.renderer.render(this.scene, this.camera);
    }
}

// Initialize game when page loads
window.addEventListener('load', () => {
    new Game();
});
