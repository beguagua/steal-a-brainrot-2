class MobileControls {
    constructor(gameInstance) {
        this.game = gameInstance;
        this.joystickContainer = document.getElementById('joystickContainer');
        this.joystickThumb = document.getElementById('joystickThumb');
        this.actionBtnE = document.getElementById('actionBtnE');
        this.actionBtnG = document.getElementById('actionBtnG');

        this.joystickActive = false;
        this.joystickStartX = 0;
        this.joystickStartY = 0;
        this.joystickCurrentX = 0;
        this.joystickCurrentY = 0;

        this.init();
    }

    init() {
        if (!this.joystickContainer || !this.joystickThumb) {
            console.warn('Mobile controls elements not found. Skipping initialization.');
            return;
        }

        this.joystickContainer.addEventListener('touchstart', this.onJoystickStart.bind(this));
        this.joystickContainer.addEventListener('touchmove', this.onJoystickMove.bind(this));
        this.joystickContainer.addEventListener('touchend', this.onJoystickEnd.bind(this));

        this.actionBtnE.addEventListener('click', () => this.simulateKeyPress('KeyE'));
        this.actionBtnG.addEventListener('click', () => this.simulateKeyPress('KeyG'));

        // Check if mobile controls should be displayed
        this.checkMobileDisplay();
        window.addEventListener('resize', this.checkMobileDisplay.bind(this));
    }

    checkMobileDisplay() {
        const mobileControls = document.getElementById('mobileControls');
        if (window.innerWidth <= 768) {
            mobileControls.style.display = 'flex';
        } else {
            mobileControls.style.display = 'none';
        }
    }

    onJoystickStart(event) {
        event.preventDefault();
        this.joystickActive = true;
        const touch = event.touches[0];
        this.joystickStartX = touch.clientX;
        this.joystickStartY = touch.clientY;
        this.joystickThumb.style.transition = 'none';
    }

    onJoystickMove(event) {
        event.preventDefault();
        if (!this.joystickActive) return;

        const touch = event.touches[0];
        this.joystickCurrentX = touch.clientX;
        this.joystickCurrentY = touch.clientY;

        const deltaX = this.joystickCurrentX - this.joystickStartX;
        const deltaY = this.joystickCurrentY - this.joystickStartY;

        const maxDistance = this.joystickContainer.offsetWidth / 2 - this.joystickThumb.offsetWidth / 2;
        const angle = Math.atan2(deltaY, deltaX);
        const distance = Math.min(maxDistance, Math.sqrt(deltaX * deltaX + deltaY * deltaY));

        const thumbX = Math.cos(angle) * distance;
        const thumbY = Math.sin(angle) * distance;

        this.joystickThumb.style.transform = `translate(${thumbX}px, ${thumbY}px)`;

        // Simulate key presses based on joystick direction
        this.game.keys = {}; // Reset keys
        if (distance > maxDistance * 0.2) { // Only activate if moved enough
            if (Math.abs(deltaX) > Math.abs(deltaY)) { // Horizontal movement dominant
                if (deltaX > 0) this.game.keys['KeyD'] = true; // Right
                else this.game.keys['KeyA'] = true; // Left
            } else { // Vertical movement dominant
                if (deltaY > 0) this.game.keys['KeyS'] = true; // Down
                else this.game.keys['KeyW'] = true; // Up
            }
        }
    }

    onJoystickEnd(event) {
        event.preventDefault();
        this.joystickActive = false;
        this.joystickThumb.style.transition = 'transform 0.2s ease-out';
        this.joystickThumb.style.transform = 'translate(-50%, -50%)'; // Reset thumb position
        this.game.keys = {}; // Release all keys
    }

    simulateKeyPress(keyCode) {
        // Simulate key down
        this.game.keys[keyCode] = true;
        // Simulate key up after a short delay
        setTimeout(() => {
            this.game.keys[keyCode] = false;
        }, 100);
    }
}

