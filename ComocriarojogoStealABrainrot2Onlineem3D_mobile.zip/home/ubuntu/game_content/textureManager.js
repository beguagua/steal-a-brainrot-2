import * as THREE from 'three';

export class TextureManager {
    constructor() {
        this.loader = new THREE.TextureLoader();
        this.textures = new Map();
        this.loadingPromises = new Map();
    }

    async loadTexture(name, path) {
        // Return existing texture if already loaded
        if (this.textures.has(name)) {
            return this.textures.get(name);
        }

        // Return existing promise if already loading
        if (this.loadingPromises.has(name)) {
            return this.loadingPromises.get(name);
        }

        // Create new loading promise
        const promise = new Promise((resolve, reject) => {
            this.loader.load(
                path,
                (texture) => {
                    // Configure texture settings
                    texture.wrapS = THREE.RepeatWrapping;
                    texture.wrapT = THREE.RepeatWrapping;
                    texture.magFilter = THREE.NearestFilter;
                    texture.minFilter = THREE.NearestFilter;
                    
                    this.textures.set(name, texture);
                    this.loadingPromises.delete(name);
                    resolve(texture);
                },
                undefined,
                (error) => {
                    console.error(`Erro ao carregar textura ${name}:`, error);
                    this.loadingPromises.delete(name);
                    reject(error);
                }
            );
        });

        this.loadingPromises.set(name, promise);
        return promise;
    }

    async loadAllTextures() {
        const textureList = [
            { name: 'tralalero', path: 'assets/textures/tralalero_texture.png' },
            { name: 'cappuccino', path: 'assets/textures/cappuccino_texture.png' },
            { name: 'bombardino', path: 'assets/textures/bombardino_texture.png' },
            { name: 'ground', path: 'assets/textures/ground_texture.png' },
            { name: 'market_sign', path: 'assets/textures/market_sign.png' }
        ];

        const promises = textureList.map(tex => this.loadTexture(tex.name, tex.path));
        
        try {
            await Promise.all(promises);
            console.log('Todas as texturas carregadas com sucesso!');
        } catch (error) {
            console.error('Erro ao carregar texturas:', error);
        }
    }

    getTexture(name) {
        return this.textures.get(name);
    }

    createBrainrotMaterial(type) {
        const texture = this.getTexture(type);
        if (texture) {
            return new THREE.MeshLambertMaterial({ 
                map: texture,
                transparent: true,
                alphaTest: 0.1
            });
        }
        
        // Fallback colors if texture not found
        const fallbackColors = {
            'tralalero': 0xff69b4,
            'cappuccino': 0x8B4513,
            'bombardino': 0x32CD32,
            'tung_sahur': 0xFFD700,
            'rare_meme': 0xFF6B6B
        };
        
        return new THREE.MeshLambertMaterial({ 
            color: fallbackColors[type] || 0xff69b4,
            transparent: true,
            opacity: 0.8
        });
    }

    createGroundMaterial() {
        const texture = this.getTexture('ground');
        if (texture) {
            texture.repeat.set(20, 20);
            return new THREE.MeshLambertMaterial({ 
                map: texture
            });
        }
        
        return new THREE.MeshLambertMaterial({ 
            color: 0x90EE90,
            transparent: true,
            opacity: 0.8
        });
    }

    createMarketSignMaterial() {
        const texture = this.getTexture('market_sign');
        if (texture) {
            return new THREE.MeshBasicMaterial({ 
                map: texture,
                transparent: true,
                alphaTest: 0.1
            });
        }
        
        return new THREE.MeshBasicMaterial({ 
            color: 0xffffff,
            transparent: true,
            opacity: 0.9
        });
    }

    // Create animated materials for special effects
    createGlowMaterial(color = 0xff6b6b, intensity = 0.5) {
        return new THREE.MeshBasicMaterial({
            color: color,
            transparent: true,
            opacity: intensity,
            blending: THREE.AdditiveBlending
        });
    }

    createShieldMaterial() {
        return new THREE.MeshBasicMaterial({
            color: 0x00ffff,
            transparent: true,
            opacity: 0.3,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
    }

    // Utility method to create particle materials
    createParticleMaterial(color = 0xffffff, size = 1.0) {
        return new THREE.PointsMaterial({
            color: color,
            size: size,
            transparent: true,
            opacity: 0.8,
            blending: THREE.AdditiveBlending,
            vertexColors: false
        });
    }

    // Create building materials
    createBuildingMaterials() {
        return {
            wall: new THREE.MeshLambertMaterial({ color: 0x8B4513 }),
            trap: new THREE.MeshLambertMaterial({ color: 0xff0000 }),
            decoration: new THREE.MeshLambertMaterial({ color: 0xff69b4 }),
            defense: new THREE.MeshLambertMaterial({ color: 0x4169E1 }),
            base_platform: new THREE.MeshLambertMaterial({ color: 0x8B4513 }),
            pedestal: new THREE.MeshLambertMaterial({ color: 0xffd700 })
        };
    }

    // Dispose of all textures to free memory
    dispose() {
        this.textures.forEach(texture => {
            texture.dispose();
        });
        this.textures.clear();
        this.loadingPromises.clear();
    }
}
