import * as THREE from 'three';

export class GameplayManager {
    constructor(game) {
        this.game = game;
        this.currentMode = 'explore'; // explore, build, steal, shop
        this.selectedObject = null;
        this.buildingMode = false;
        this.stealingTarget = null;
        this.inventory = [];
        this.buildingPreviews = new Map();
        this.interactionRange = 10;
        this.stealCooldown = 0;
        this.buildCost = {
            wall: 50,
            trap: 100,
            decoration: 25,
            defense: 150
        };
        
        this.setupGameplayEvents();
    }

    setupGameplayEvents() {
        // Build mode toggle
        document.getElementById('buildBtn').addEventListener('click', () => {
            this.toggleBuildMode();
        });

        // Shop interaction
        document.getElementById('shopBtn').addEventListener('click', () => {
            this.openShop();
        });

        // Steal mode toggle
        document.getElementById('stealBtn').addEventListener('click', () => {
            this.toggleStealMode();
        });

        // Additional keyboard shortcuts
        document.addEventListener('keydown', (event) => {
            this.handleGameplayKeys(event);
        });
    }

    handleGameplayKeys(event) {
        switch(event.code) {
            case 'KeyB':
                this.toggleBuildMode();
                break;
            case 'KeyT':
                this.toggleStealMode();
                break;
            case 'KeyF':
                this.interactWithNearestObject();
                break;
            case 'KeyR':
                this.activateShield();
                break;
            case 'Escape':
                this.cancelCurrentAction();
                break;
        }
    }

    toggleBuildMode() {
        this.buildingMode = !this.buildingMode;
        this.currentMode = this.buildingMode ? 'build' : 'explore';
        
        const buildBtn = document.getElementById('buildBtn');
        if (this.buildingMode) {
            buildBtn.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)';
            buildBtn.textContent = '🔨 Construindo';
            this.showBuildingUI();
        } else {
            buildBtn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
            buildBtn.textContent = '🏗️ Construir';
            this.hideBuildingUI();
            this.clearBuildingPreviews();
        }
    }

    showBuildingUI() {
        // Create building UI panel
        if (!document.getElementById('buildingPanel')) {
            const buildingPanel = document.createElement('div');
            buildingPanel.id = 'buildingPanel';
            buildingPanel.className = 'ui-panel';
            buildingPanel.style.cssText = `
                position: absolute;
                top: 100px;
                left: 20px;
                width: 250px;
                display: flex;
                flex-direction: column;
                gap: 10px;
            `;

            const buildingOptions = [
                { type: 'wall', name: 'Parede', cost: 50, icon: '🧱' },
                { type: 'trap', name: 'Armadilha', cost: 100, icon: '⚡' },
                { type: 'decoration', name: 'Decoração', cost: 25, icon: '🌸' },
                { type: 'defense', name: 'Defesa', cost: 150, icon: '🛡️' }
            ];

            buildingOptions.forEach(option => {
                const button = document.createElement('button');
                button.className = 'action-btn';
                button.style.fontSize = '14px';
                button.innerHTML = `${option.icon} ${option.name} - $${option.cost}`;
                button.addEventListener('click', () => this.selectBuildingType(option.type));
                buildingPanel.appendChild(button);
            });

            document.getElementById('ui').appendChild(buildingPanel);
        }
    }

    hideBuildingUI() {
        const buildingPanel = document.getElementById('buildingPanel');
        if (buildingPanel) {
            buildingPanel.remove();
        }
    }

    selectBuildingType(type) {
        this.selectedBuildingType = type;
        console.log(`Tipo de construção selecionado: ${type}`);
        
        // Update cursor or visual feedback
        document.body.style.cursor = 'crosshair';
    }

    toggleStealMode() {
        const isStealMode = this.currentMode === 'steal';
        this.currentMode = isStealMode ? 'explore' : 'steal';
        
        const stealBtn = document.getElementById('stealBtn');
        if (this.currentMode === 'steal') {
            stealBtn.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)';
            stealBtn.textContent = '🔍 Procurando';
            this.highlightStealableTargets();
        } else {
            stealBtn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
            stealBtn.textContent = '💰 Roubar';
            this.clearStealHighlights();
        }
    }

    highlightStealableTargets() {
        // Highlight other players' bases that can be robbed
        this.game.bases.forEach((base, playerId) => {
            if (playerId !== this.game.socket.id) {
                // Add glowing effect to stealable bases
                const glowMaterial = new THREE.MeshBasicMaterial({
                    color: 0xff0000,
                    transparent: true,
                    opacity: 0.3
                });
                
                const glowGeometry = new THREE.CylinderGeometry(10, 10, 0.1, 16);
                const glowMesh = new THREE.Mesh(glowGeometry, glowMaterial);
                glowMesh.position.copy(base.position);
                glowMesh.position.y += 0.1;
                
                this.game.scene.add(glowMesh);
                this.stealHighlights = this.stealHighlights || [];
                this.stealHighlights.push(glowMesh);
            }
        });
    }

    clearStealHighlights() {
        if (this.stealHighlights) {
            this.stealHighlights.forEach(highlight => {
                this.game.scene.remove(highlight);
            });
            this.stealHighlights = [];
        }
    }

    interactWithNearestObject() {
        if (!this.game.player) return;

        const playerPos = this.game.player.position;
        let nearestObject = null;
        let nearestDistance = this.interactionRange;

        // Check for nearby brainrots
        this.game.brainrots.forEach((brainrot, id) => {
            const distance = this.calculateDistance(playerPos, brainrot.position);
            if (distance < nearestDistance) {
                nearestObject = { type: 'brainrot', object: brainrot, id: id };
                nearestDistance = distance;
            }
        });

        // Check for nearby bases
        this.game.bases.forEach((base, playerId) => {
            if (playerId !== this.game.socket.id) {
                const distance = this.calculateDistance(playerPos, base.position);
                if (distance < nearestDistance) {
                    nearestObject = { type: 'base', object: base, id: playerId };
                    nearestDistance = distance;
                }
            }
        });

        if (nearestObject) {
            this.handleObjectInteraction(nearestObject);
        }
    }

    handleObjectInteraction(objectData) {
        switch (objectData.type) {
            case 'brainrot':
                if (this.currentMode === 'steal') {
                    this.attemptSteal(objectData.id);
                }
                break;
            case 'base':
                if (this.currentMode === 'steal') {
                    this.attemptBaseRaid(objectData.id);
                }
                break;
        }
    }

    attemptSteal(brainrotId) {
        if (this.stealCooldown > 0) {
            this.showMessage('Aguarde antes de tentar roubar novamente!');
            return;
        }

        const brainrot = this.game.brainrots.get(brainrotId);
        if (brainrot && brainrot.userData.brainrotData.owner !== this.game.socket.id) {
            this.game.socket.emit('attemptSteal', brainrot.userData.brainrotData.owner);
            this.stealCooldown = 5000; // 5 second cooldown
            
            setTimeout(() => {
                this.stealCooldown = 0;
            }, 5000);
        }
    }

    attemptBaseRaid(targetPlayerId) {
        if (this.stealCooldown > 0) {
            this.showMessage('Aguarde antes de tentar roubar novamente!');
            return;
        }

        this.game.socket.emit('attemptSteal', targetPlayerId);
        this.stealCooldown = 3000; // 3 second cooldown
        
        setTimeout(() => {
            this.stealCooldown = 0;
        }, 3000);
    }

    activateShield() {
        if (this.game.player && this.game.player.money >= 100) {
            this.game.socket.emit('activateShield');
            this.showMessage('Escudo ativado por 60 segundos!');
        } else {
            this.showMessage('Dinheiro insuficiente para ativar escudo!');
        }
    }

    openShop() {
        this.showShopUI();
    }

    showShopUI() {
        // Remove existing shop if present
        const existingShop = document.getElementById('shopPanel');
        if (existingShop) {
            existingShop.remove();
            return;
        }

        const shopPanel = document.createElement('div');
        shopPanel.id = 'shopPanel';
        shopPanel.className = 'ui-panel';
        shopPanel.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            max-height: 500px;
            overflow-y: auto;
            z-index: 200;
        `;

        const shopTitle = document.createElement('h2');
        shopTitle.textContent = '🛒 Loja de Brainrots';
        shopTitle.style.textAlign = 'center';
        shopTitle.style.marginBottom = '20px';
        shopPanel.appendChild(shopTitle);

        // Mock shop items
        const shopItems = [
            { id: 'shop_1', type: 'tralalero', name: 'Tralalero Tralala', price: 150, rarity: 'comum' },
            { id: 'shop_2', type: 'cappuccino', name: 'Cappuccino Assassino', price: 200, rarity: 'raro' },
            { id: 'shop_3', type: 'bombardino', name: 'Bombardino Crocodilo', price: 300, rarity: 'épico' },
            { id: 'shop_4', type: 'tung_sahur', name: 'Tung Tung Sahur', price: 400, rarity: 'lendário' },
            { id: 'shop_5', type: 'rare_meme', name: 'Meme Raro Especial', price: 750, rarity: 'mítico' }
        ];

        shopItems.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.style.cssText = `
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                margin: 10px 0;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                border: 2px solid ${this.getRarityColor(item.rarity)};
            `;

            const itemInfo = document.createElement('div');
            itemInfo.innerHTML = `
                <strong>${item.name}</strong><br>
                <small style="color: ${this.getRarityColor(item.rarity)}">${item.rarity.toUpperCase()}</small>
            `;

            const buyButton = document.createElement('button');
            buyButton.className = 'action-btn';
            buyButton.style.fontSize = '12px';
            buyButton.textContent = `$${item.price}`;
            buyButton.addEventListener('click', () => this.buyItem(item));

            itemDiv.appendChild(itemInfo);
            itemDiv.appendChild(buyButton);
            shopPanel.appendChild(itemDiv);
        });

        const closeButton = document.createElement('button');
        closeButton.className = 'action-btn';
        closeButton.textContent = '❌ Fechar';
        closeButton.style.width = '100%';
        closeButton.style.marginTop = '20px';
        closeButton.addEventListener('click', () => shopPanel.remove());
        shopPanel.appendChild(closeButton);

        document.getElementById('ui').appendChild(shopPanel);
    }

    getRarityColor(rarity) {
        const colors = {
            'comum': '#ffffff',
            'raro': '#00ff00',
            'épico': '#9d4edd',
            'lendário': '#ffd700',
            'mítico': '#ff6b6b'
        };
        return colors[rarity] || '#ffffff';
    }

    buyItem(item) {
        if (this.game.player && this.game.player.money >= item.price) {
            this.game.socket.emit('buyBrainrot', item.id);
            this.showMessage(`Comprando ${item.name}...`);
        } else {
            this.game.audioManager.playSound('error');
            this.showMessage('Dinheiro insuficiente!');
        }
    }

    handleMouseClick(event, intersects) {
        if (this.buildingMode && this.selectedBuildingType) {
            this.placeBuildingItem(intersects);
        } else if (this.currentMode === 'steal') {
            this.handleStealClick(intersects);
        }
    }

    placeBuildingItem(intersects) {
        if (intersects.length > 0) {
            const point = intersects[0].point;
            const cost = this.buildCost[this.selectedBuildingType];
            
            if (this.game.player.money >= cost) {
                this.createBuildingItem(this.selectedBuildingType, point);
                this.game.player.money -= cost;
                this.game.updateUI();
                this.game.audioManager.playSound('build');
                this.showMessage(`${this.selectedBuildingType} construído!`);
            } else {
                this.game.audioManager.playSound('error');
                this.showMessage('Dinheiro insuficiente!');
            }
        }
    }

    createBuildingItem(type, position) {
        let geometry, material, mesh;

        switch (type) {
            case 'wall':
                geometry = new THREE.BoxGeometry(4, 3, 0.5);
                material = new THREE.MeshLambertMaterial({ color: 0x8B4513 });
                break;
            case 'trap':
                geometry = new THREE.ConeGeometry(1, 2, 6);
                material = new THREE.MeshLambertMaterial({ color: 0xff0000 });
                break;
            case 'decoration':
                geometry = new THREE.SphereGeometry(1);
                material = new THREE.MeshLambertMaterial({ color: 0xff69b4 });
                break;
            case 'defense':
                geometry = new THREE.CylinderGeometry(1, 1.5, 4);
                material = new THREE.MeshLambertMaterial({ color: 0x4169E1 });
                break;
        }

        mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.position.y += 1;
        mesh.castShadow = true;
        mesh.receiveShadow = true;

        this.game.scene.add(mesh);
    }

    handleStealClick(intersects) {
        // Handle clicking on stealable objects
        if (intersects.length > 0) {
            const clickedObject = intersects[0].object;
            
            // Check if clicked object belongs to another player
            this.game.bases.forEach((base, playerId) => {
                if (playerId !== this.game.socket.id && base.children.includes(clickedObject)) {
                    this.attemptBaseRaid(playerId);
                }
            });
        }
    }

    cancelCurrentAction() {
        this.currentMode = 'explore';
        this.buildingMode = false;
        this.selectedBuildingType = null;
        this.clearBuildingPreviews();
        this.clearStealHighlights();
        
        // Reset UI
        document.getElementById('buildBtn').style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        document.getElementById('buildBtn').textContent = '🏗️ Construir';
        document.getElementById('stealBtn').style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        document.getElementById('stealBtn').textContent = '💰 Roubar';
        
        this.hideBuildingUI();
        document.body.style.cursor = 'default';
    }

    clearBuildingPreviews() {
        this.buildingPreviews.forEach(preview => {
            this.game.scene.remove(preview);
        });
        this.buildingPreviews.clear();
    }

    calculateDistance(pos1, pos2) {
        return Math.sqrt(
            Math.pow(pos1.x - pos2.x, 2) +
            Math.pow(pos1.z - pos2.z, 2)
        );
    }

    showMessage(text) {
        // Create temporary message overlay
        const messageDiv = document.createElement('div');
        messageDiv.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 20px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            z-index: 1000;
            animation: fadeInOut 3s ease-in-out;
        `;
        messageDiv.textContent = text;

        // Add fade animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                20% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(messageDiv);

        setTimeout(() => {
            messageDiv.remove();
            style.remove();
        }, 3000);
    }

    update() {
        // Update cooldowns and other time-based mechanics
        if (this.stealCooldown > 0) {
            this.stealCooldown -= 16; // Assuming 60fps
        }
    }
}
